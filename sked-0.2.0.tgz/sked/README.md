# Sked Helm chart

## Install

Install [cert-manager](https://cert-manager.io/docs/installation/) first, then run:

```sh
helm repo add schedkit https://schedkit.github.io/sked
helm repo update
helm install sked schedkit/sked \
  --namespace sked-system --create-namespace \
  --wait --timeout 5m
```

Add `--version 1.2.3` to pin a release. Prereleases require an explicit version
such as `--version 1.2.3-rc.1` or `--devel`. The chart archive is also attached to
its [GitHub Release](https://github.com/schedkit/sked/releases).
For development installs from a checkout, use `./charts/sked` instead of
`schedkit/sked`.

Helm 3 and 4 are supported. Installation needs permission to create CRDs, cluster
RBAC, and admission webhooks. Nodes running schedulers need sched_ext support.

Use **one Sked installation per cluster**: every controller watches all Scheduler
objects. Don't install this alongside a Kustomize deployment; the chart does not
adopt its resources.

## Configure

Pass overrides with `-f my-values.yaml`. The full list is in
[values.yaml](values.yaml). For example:

```yaml
replicaCount: 3
controller:
  reconcileTimeout: 30s
  maxConcurrentReconciles: 4
resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: "1"
    memory: 256Mi
```

Scheduler DaemonSets run in the release namespace unless you set
`controller.workloadNamespace` to another existing namespace.

The image defaults to `ghcr.io/schedkit/sked` at `Chart.yaml`'s `appVersion`.
Override `image.tag` or `image.digest`; a digest wins if both are set.
`imagePullSecrets` must refer to secrets in the release namespace.

To reuse a service account, set `serviceAccount.create=false` and
`serviceAccount.name`. Set `rbac.create=false` only if you provide the roles and
bindings yourself.

### Availability

The defaults are two replicas, leader election enabled, and a PodDisruptionBudget
with `minAvailable: 1`. Only the leader reconciles; followers wait to take over
but still serve webhooks and use CPU and memory. Adding replicas does not increase
reconciliation throughput. Existing scheduler DaemonSets keep running even if all
controllers are down, but reconciliation and status updates stop.

A soft topology-spread rule prefers different nodes using `kubernetes.io/hostname`.
It allows replicas to share a node, so single-node installs still work. At least
two schedulable nodes are needed to survive a node failure. The PDB protects
against voluntary evictions, not node failures or direct pod deletion.

Use `replicaCount` to change the number of controllers. The chart rejects multiple
replicas with `controller.leaderElection=false`; don't bypass this through
`controller.extraArgs`. `podDisruptionBudget.minAvailable` accepts an integer or
a percentage such as `"50%"`. Setting it equal to the replica count blocks drains.
For a single-replica development install without eviction protection:

```yaml
replicaCount: 1
podDisruptionBudget:
  enabled: false
```

`topologySpreadConstraints: null` uses the default rule with this release's pod
selector. Set it to `[]` to disable spreading, or supply a list of Kubernetes
spread constraints to replace the rule. Custom constraints must include a
`labelSelector` matching the controller pods. `nodeSelector`, `tolerations`, and
`affinity` can also restrict placement.

### Logging

By default, the controller writes newline-delimited Slog JSON to stderr at info
level. The chart does not inject logging flags. To use text output and debug
logging:

```yaml
controller:
  extraArgs:
    - --log-format=text
    - --log-level=debug
```

`--log-format` accepts `json` or `text`; `--log-level` accepts `info`, `debug`, or
`error`. Debug enables Logr `V(1)` through `V(4)`. For a precise threshold, use
`--log-verbosity=N` instead of `--log-level`, for example:

```yaml
controller:
  extraArgs:
    - --log-verbosity=2
```

Do not explicitly combine level and verbosity flags; the controller rejects that
configuration. Verbosity accepts integers from `0` to `2147483647`.

JSON uses `time`, `level`, `msg`, optional `logger`, and `err` for Logr errors.
Severity names are native Slog names (`INFO`, `ERROR`, `DEBUG`, or intermediate
values such as `DEBUG+3`); logger names are slash-separated. Automatic error stack
traces and backend sampling are disabled. No-op reconciles log at `V(1)`; workload
changes remain at info. Sigstore/Rekor retains independently configured logging
and a transitive Zap dependency.

#### Migrating logging overrides

**All `--zap-*` arguments now prevent startup.** Update saved values before
upgrading; there is no compatibility layer. For example, replace:

```yaml
controller:
  extraArgs:
    - --zap-devel=true
    - --zap-log-level=debug
```

with the following to retain text output and the old `V(1)` threshold:

```yaml
controller:
  extraArgs:
    - --log-format=text
    - --log-verbosity=1
```

Remove `--zap-devel=false` without replacement for default JSON/info logging.
Log queries must use `time` instead of `ts`, `err` instead of `error`, uppercase
severity names, and slash-separated logger names. The
[controller logging documentation](../../README.md#controller-logging) covers the
full output contract, object-logging safeguards, and standalone migration examples.

### Trust policy

The default policy allows signed Schedkit scheduler images, matching
[`config/trustpolicy/trust_policy.yaml`](../../config/trustpolicy/trust_policy.yaml).
To replace it:

```yaml
trustPolicy:
  policy:
    allowedImages:
      - ghcr.io/my-org/my-scheduler
    verifySignatures: true
    cosign:
      issuer: https://token.actions.githubusercontent.com
      identity: https://github.com/my-org/my-scheduler/.github/workflows/release.yml@refs/heads/main
```

Or set `trustPolicy.existingConfigMap` to a ConfigMap you manage separately.
`trustPolicy.namespace` defaults to the release namespace; `trustPolicy.key`
defaults to `policy.yaml`. Changes to a chart-managed policy restart the controller
on upgrade.

### Webhook certificates

The webhook is always on. By default, cert-manager issues its certificate through
a self-signed Issuer created by the chart. To use an existing issuer:

```yaml
webhook:
  certManager:
    issuerRef:
      name: platform-ca
      kind: ClusterIssuer
```

Without cert-manager, set these three values:

- `webhook.certManager.enabled: false`
- `webhook.secretName`: a secret in the release namespace with `tls.crt` and `tls.key`
- `webhook.caBundle`: the base64-encoded PEM CA certificate

The certificate must cover `<fullname>-webhook-service.<namespace>.svc` and
`<fullname>-webhook-service.<namespace>.svc.cluster.local`. You handle rotation
when supplying your own secret.

### Metrics

Metrics use authenticated HTTPS on port 8443. With Prometheus Operator installed:

```yaml
metrics:
  serviceMonitor:
    enabled: true
  readerSubjects:
    - kind: ServiceAccount
      name: prometheus
      namespace: monitoring
```

Set `metrics.serviceMonitor.labels` if Prometheus selects monitors by label.
The controller uses a self-signed metrics certificate, so the default monitor
skips certificate verification, just like the Kustomize monitor. Webhook
certificates do not configure metrics TLS. Setting `metrics.secure=false` also
removes metrics authentication.

Enable `networkPolicy.enabled` to restrict metrics ingress to namespaces labeled
`metrics: enabled`. Webhook ingress stays open for the API server. Your CNI must
enforce NetworkPolicy for this to have any effect.

## Upgrade and rollback

Before upgrading from a Zap-based controller, remove legacy logging flags from
`controller.extraArgs`, including stored values used with `--reuse-values`.
Follow the [logging migration](#migrating-logging-overrides); old flags prevent
controller startup. When rolling back, restore flags supported by the old binary.

Helm **does not upgrade CRDs**. Choose the chart version you want to deploy,
apply its CRDs first, then upgrade using your saved values:

```sh
version=1.2.3
helm repo update
helm show crds schedkit/sked --version "$version" | kubectl apply -f -
helm upgrade sked schedkit/sked --version "$version" \
  --namespace sked-system -f my-values.yaml \
  --wait --timeout 5m
```

For a local checkout, apply `./charts/sked/crds/` and upgrade using
`./charts/sked` instead.

Don't change the release name, namespace, `nameOverride`, or `fullnameOverride`
on upgrade; they determine resource names and Deployment selectors.

```sh
helm history sked --namespace sked-system
helm rollback sked <revision> --namespace sked-system --wait --timeout 5m
```

Rollback does not restore CRDs or Scheduler objects. Check that the old controller
supports the installed schema before rolling back.

## Uninstall

```sh
helm uninstall sked --namespace sked-system
```

The CRD, Scheduler objects, and their DaemonSets stay behind. To stop schedulers,
delete their Scheduler objects and wait for the DaemonSets to disappear **before**
uninstalling. Deleting the CRD removes every Scheduler object in the cluster.

## Working on the chart

CRDs and `files/` are generated from `config/`; don't edit those copies directly.
After changing the API, RBAC, webhook rules, or default trust policy:

```sh
make helm-sync
make test-helm
```

CI checks for stale generated files and compares rendered defaults with Kustomize
on Helm 3 and 4. To test installation, failover, eviction protection, upgrade,
rollback, and uninstall locally, run `make test-helm-e2e`. It needs Docker and Kind,
creates a temporary cluster with two workers, and removes it afterward.

Tagged releases derive `version` and `appVersion` from the Git tag without
changing the checked-in `Chart.yaml`. For example, `v1.2.3` produces chart version
`1.2.3` and `appVersion: "v1.2.3"`. Chart and controller releases share a version;
do not release chart versions independently. To package a release locally:

```sh
bash hack/package-helm.sh v1.2.3 /tmp/sked-chart
```

See [release setup](../../README.md#releases-and-helm-repository) for publication
to GitHub Releases and the `gh-pages` Helm repository.
